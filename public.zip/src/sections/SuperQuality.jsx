

const SuperQuality = () => {
  return (
    <div>SuperQuality</div>
  )
}

export default SuperQuality