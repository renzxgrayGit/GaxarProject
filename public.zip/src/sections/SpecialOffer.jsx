

const SpecialOffer = () => {
  return (
    <div>SpecialOffer</div>
  )
}

export default SpecialOffer